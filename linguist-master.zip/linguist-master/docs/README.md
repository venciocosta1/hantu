# Linguist Documentation

- [How Linguist works](how-linguist-works.md)
- [Change Linguist's behaviour with overrides](overrides.md)
- [Troubleshooting](troubleshooting.md)
- [Contributing guidelines](/CONTRIBUTING.md)
- [Releasing Linguist](releasing.md) (Only applicable to GitHub staff)
