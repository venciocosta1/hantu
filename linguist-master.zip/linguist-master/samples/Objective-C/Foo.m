#import "Foo.h"


@implementation Foo

@end
