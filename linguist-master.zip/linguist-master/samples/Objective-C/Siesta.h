//
//  Siesta.h
//  Siesta
//
//  Created by Paul on 2015/6/14.
//  Copyright © 2015 Bust Out Solutions. MIT license.
//

#import <UIKit/UIKit.h>

//! Project version number for Siesta.
FOUNDATION_EXPORT double SiestaVersionNumber;

//! Project version string for Siesta.
FOUNDATION_EXPORT const unsigned char SiestaVersionString[];

