constexpr double VERSION_NUMBER {1.2};

constexpr int FRAME_RATE {60};
constexpr int MIN_FRAME_RATE {30};
