class Bar
{
  protected:

    char *name;

  public:

    void hello();
}
