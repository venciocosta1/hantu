(* Paclet Info File *)

(* created 2014/02/07*)

Paclet[
    Name -> "Foobar",
    Version -> "0.0.1",
    MathematicaVersion -> "8+",
    Description -> "Example of an automatically generated PacletInfo file.",
    Creator -> "Chris Granade",
    Extensions -> 
        {
            {"Documentation", Language -> "English", MainPage -> "Guides/Foobar"}
        }
]


