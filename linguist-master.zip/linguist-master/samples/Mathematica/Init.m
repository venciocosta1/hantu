(* Mathematica Init File *)

Get[ "Foobar`Foobar`"]
