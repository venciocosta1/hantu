module Foo
end
