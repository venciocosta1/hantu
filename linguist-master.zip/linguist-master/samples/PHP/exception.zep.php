<?php

namespace Test\Router;

class Exception extends \Exception
{

}
