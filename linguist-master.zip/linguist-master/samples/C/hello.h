#ifndef HELLO_H
#define HELLO_H

void hello();

#endif
