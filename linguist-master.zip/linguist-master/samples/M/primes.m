	; part of Keith Lynch's .signature; it prints a table of primes,
	; including code to format it neatly into columns -- DPBS
	;    -- M Technology and MUMPS Language FAQ, Part 1/2
	;

	f p=2,3:2 s q=1 x "f f=3:2 q:f*f>p!'q  s q=p#f" w:q p,?$x\8+1*8
