use Mojolicious::Lite;
use 5.20.0;
use experimental 'signatures';
