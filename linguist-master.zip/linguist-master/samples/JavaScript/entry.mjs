import bar from './module.mjs';
function foo() {
  return "I am foo";
}
export {foo};
console.log(bar);
