(function() {
  console.log("Hello, World!");
}).call(this);
