import {foo} from './entry.mjs';
console.log(foo());

const bar = "I am bar.";
export {bar as default};
