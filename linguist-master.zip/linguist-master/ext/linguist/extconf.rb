require 'mkmf'
dir_config('linguist')
create_makefile('linguist/linguist')
