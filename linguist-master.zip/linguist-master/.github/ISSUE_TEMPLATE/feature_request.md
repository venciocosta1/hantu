---
name: Feature request
about: Suggest an enhancement
title: ''
labels: Improvement
assignees: ''
---

## Describe the enhancement

<!--

Please let us know what enhancement you'd like to see made to Linguist. The more
detail you provide, the better.

-->
