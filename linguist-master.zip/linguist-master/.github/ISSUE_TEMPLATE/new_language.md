---
name: New language
about: Request support for a new language
title: ''
labels: Add Language, Good First Issue
assignees: ''
---

<!--

👋 If you have the time and know-how, send us a pull-request: everybody is welcome to contribute! 
Otherwise, fill out the following fields as best you can.

-->
## Language name


## URL of example repository


## URL of syntax highlighting grammar


## Most popular extensions

<!--

List the extensions commonly used by this language.

-->

## Detected language

<!--

What language are files for this language being identified as, if any?

-->
